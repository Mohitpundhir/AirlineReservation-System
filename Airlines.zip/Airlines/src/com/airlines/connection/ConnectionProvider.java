package com.airlines.connection;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Enumeration;
import java.util.Properties;

public class ConnectionProvider 
{
	private static Properties properties;
	private static FileInputStream fileInputStream;
	private static Enumeration<String> enumeration;
	private static Connection connection;
	private static String url;
	private static String username;
	private static String password;

	@SuppressWarnings({ "unchecked", "finally" })
	public static Connection getConnection()
	{
		try 
		{
			properties = new Properties();
			fileInputStream = new FileInputStream("C:\\Users\\MOHIT\\Desktop\\BCA PROJECT\\Airlines\\src\\com\\airlines\\connection\\database.properties");
			properties.load(fileInputStream);
			enumeration = (Enumeration<String>) properties.propertyNames();
			
			while(enumeration.hasMoreElements())
			{
				String key   = enumeration.nextElement();
				String value = properties.getProperty(key);
				
				if(key.equals("url"))
					url = value;

				else if(key.equals("username"))
					username = value;
				
				else if(key.equals("password"))
					password = value;
			}
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(url, username, password);
		}
		
		catch (Exception e) 
		{
			System.out.println("-------------- EXCEPTION FROM CONNECTIONPROVIDER.JAVA ---------------");
			e.printStackTrace();
		}
		
		finally 
		{
			return connection;
		}
		
	}
}
